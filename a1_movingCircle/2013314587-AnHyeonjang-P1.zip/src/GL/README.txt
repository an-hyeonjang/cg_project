slee's README for OpenGL 3rd party libraries

1. How to use version-dependent OpenGL (with glad library)
a) extract glad-*.7z of the OpenGL version you need to use.
b) move glad.h/glad.c to glad directory
